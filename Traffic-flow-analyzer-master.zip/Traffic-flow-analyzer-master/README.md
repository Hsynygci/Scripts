# Traffic-flow-analyzer

Colletcs all traffic data from NIC. separate them to flows and alculate send, receive size and duration time.
Alogrithm based on SourceIP:SourcePort:DesIP:DestPort
Only works with Ubuntu.

Usage:
python flow_analayzer.py
